package com.TicketXChange.TicketXChange.ticket.enums;

public enum VerificationStatus {
    APPROVED,
    PENDING,
    FAILED,
    REJECTED
}
