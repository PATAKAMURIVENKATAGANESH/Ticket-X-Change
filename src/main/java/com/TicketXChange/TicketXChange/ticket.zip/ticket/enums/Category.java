package com.TicketXChange.TicketXChange.ticket.enums;

public enum Category {
    MOVIE,
    TRAVEL,
    EVENT,
    HOTEL
}
