package com.TicketXChange.TicketXChange.ticket.enums;

public enum FeedbackStatus {
    DONE,
    SPAMMED
}
