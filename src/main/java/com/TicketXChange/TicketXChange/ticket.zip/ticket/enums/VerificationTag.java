package com.TicketXChange.TicketXChange.ticket.enums;

public enum VerificationTag {
    VERIFIED,
    REJECTED,
    UNVERIFIED
}
