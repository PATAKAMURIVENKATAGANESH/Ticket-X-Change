package com.TicketXChange.TicketXChange.ticket.enums;

public enum AvailabilityStatus {
        AVAILABLE,
        SOLD,
        RESERVED,
}
